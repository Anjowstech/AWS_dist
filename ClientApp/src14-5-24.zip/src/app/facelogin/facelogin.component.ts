import { Component } from '@angular/core';

@Component({
  selector: 'app-facelogin',
  templateUrl: './facelogin.component.html',
  styleUrls: ['./facelogin.component.css']
})
export class FaceloginComponent {

}
